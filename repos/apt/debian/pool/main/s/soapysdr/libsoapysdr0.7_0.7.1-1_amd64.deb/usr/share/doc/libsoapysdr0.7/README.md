# Soapy SDR - vendor and platform neutral SDR support library.

## Build Status

- Travis: [![Travis Build Status](https://travis-ci.org/pothosware/SoapySDR.svg?branch=master)](https://travis-ci.org/pothosware/SoapySDR)
- AppVeyor: [![AppVeyor Build status](https://ci.appveyor.com/api/projects/status/6chajdpy7uk5ax89)](https://ci.appveyor.com/project/guruofquality/soapysdr)

## Documentation

* https://github.com/pothosware/SoapySDR/wiki

## Licensing information

Use, modification and distribution is subject to the Boost Software
License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
http://www.boost.org/LICENSE_1_0.txt)
